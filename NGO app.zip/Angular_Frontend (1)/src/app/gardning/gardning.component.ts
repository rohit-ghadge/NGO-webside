import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gardning',
  templateUrl: './gardning.component.html',
  styleUrls: ['./gardning.component.css']
})
export class GardningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
